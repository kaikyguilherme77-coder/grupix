// supabase/functions/check-pix-payment/index.ts
// ══════════════════════════════════════════════════
// Verifica status do PIX e ativa destaque automaticamente
// Implante com: supabase functions deploy check-pix-payment
// ══════════════════════════════════════════════════

import Stripe from 'npm:stripe@14'
import { createClient } from 'npm:@supabase/supabase-js@2'

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY')!, {
  apiVersion: '2024-06-20',
})

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
)

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      },
    })
  }

  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
  }

  try {
    const { paymentIntentId } = await req.json()

    if (!paymentIntentId) {
      return new Response(JSON.stringify({ error: 'paymentIntentId obrigatório' }), { status: 400, headers })
    }

    const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId)

    if (paymentIntent.status === 'succeeded') {
      const meta = paymentIntent.metadata
      const groupId = meta.group_id
      const dias = parseInt(meta.dias || '7')
      const featuredUntil = new Date(Date.now() + dias * 24 * 60 * 60 * 1000).toISOString()

      // Ativar destaque no grupo
      await supabase.from('groups')
        .update({
          is_featured: true,
          featured_until: featuredUntil,
        })
        .eq('id', groupId)

      // Atualizar pagamento no banco
      await supabase.from('payments')
        .update({
          status: 'approved',
          featured_until: featuredUntil,
        })
        .eq('mp_payment_id', paymentIntentId)

      return new Response(JSON.stringify({
        status: 'succeeded',
        groupId,
        featuredUntil,
      }), { headers })
    }

    return new Response(JSON.stringify({ status: paymentIntent.status }), { headers })

  } catch (err: any) {
    console.error('Erro check-pix-payment:', err)
    return new Response(JSON.stringify({ error: err.message || 'Erro interno' }), { status: 500, headers })
  }
})
